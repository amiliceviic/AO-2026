/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Enum.java to edit this template
 */

package model;

/**
 *
 * @author Aleksandar Milicevic
 */
public enum StatusPrijave {
    
    U_OBRADI, ZAKLJUCANA, ZAVRSENA;

}
