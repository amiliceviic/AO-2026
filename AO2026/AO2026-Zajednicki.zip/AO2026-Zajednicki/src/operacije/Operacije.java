/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package operacije;

/**
 *
 * @author Aleksandar Milicevic
 */
public class Operacije {
    
    public static final int SIGN_UP = 1;
    public static final int LOGIN = 2;
    public static final int PRIJAVA_ZA_VOLONTIRANJE = 3;
    public static final int PREGLED_PRIJAVA = 4;
    public static final int IZMENA_PRIJAVE = 5;
    public static final int OTKAZ_PRIJAVE = 6;
    public static final int IZLAZ = 7;

}
